import robopy.base.model as model
import numpy as np


def main():
    robot = model.Puma560()

    a = np.transpose(np.asmatrix(np.linspace(1, -180, 500)))
    print("a:")
    print(a)
    b = np.transpose(np.asmatrix(np.linspace(1, 180, 500)))
    print("b:")
    print(b)
    c = np.transpose(np.asmatrix(np.linspace(1, 90, 500)))
    print("c:")
    print(c)
    d = np.transpose(np.asmatrix(np.linspace(1, 450, 500)))
    print("d:")
    print(d)
    e = np.asmatrix(np.zeros((500, 1)))
    print("e:")
    print(e)
    f = np.concatenate((d, b, a, e, c, d), axis=1)
    print("f:")
    print(f)

    robot.animate(stances=f, frame_rate=30, unit='deg')


if __name__ == '__main__':
    main()
